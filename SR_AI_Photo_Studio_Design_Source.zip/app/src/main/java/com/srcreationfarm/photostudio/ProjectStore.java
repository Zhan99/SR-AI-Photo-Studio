package com.srcreationfarm.photostudio;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.AtomicFile;
import java.io.*;
import java.util.*;

/** Local snapshot history. Original import is immutable. Each commit is atomic. */
final class ProjectStore {
    final File root; File dir; int cursor, last; static final int HISTORY=8;
    ProjectStore(File files){root=new File(files,"projects");root.mkdirs();}
    File[] list(){File[] dirs=root.listFiles(f->f.isDirectory()&&new File(f,"state").isFile());if(dirs==null)return new File[0];Arrays.sort(dirs,(a,b)->Long.compare(b.lastModified(),a.lastModified()));return dirs;}
    private File frame(int n){return new File(dir,"edit-"+n+".png");}
    private static void png(File f,Bitmap b)throws IOException{AtomicFile a=new AtomicFile(f);FileOutputStream s=a.startWrite();try{if(!b.compress(Bitmap.CompressFormat.PNG,100,s))throw new IOException("PNG encoding failed");a.finishWrite(s);}catch(Exception e){a.failWrite(s);throw e;}}
    private void state(int c,int l)throws IOException{AtomicFile a=new AtomicFile(new File(dir,"state"));FileOutputStream s=a.startWrite();try{DataOutputStream out=new DataOutputStream(s);out.writeInt(c);out.writeInt(l);out.flush();a.finishWrite(s);cursor=c;last=l;dir.setLastModified(System.currentTimeMillis());}catch(Exception e){a.failWrite(s);throw e;}}
    void create(Bitmap b)throws IOException{File old=dir;int oc=cursor,ol=last;dir=new File(root,"Project-"+System.currentTimeMillis()+"-"+UUID.randomUUID().toString().substring(0,4));if(!dir.mkdir())throw new IOException("Project directory");try{png(frame(0),b);state(0,0);}catch(Exception e){dir=old;cursor=oc;last=ol;throw e;}}
    void commit(Bitmap b)throws IOException{int n=cursor+1,oldLast=last;png(frame(n),b);state(n,n);for(int i=n+1;i<=oldLast;i++)frame(i).delete();int expired=n-HISTORY-1;if(expired>0)frame(expired).delete();}
    Bitmap open(File f)throws IOException{try(DataInputStream in=new DataInputStream(new AtomicFile(new File(f,"state")).openRead())){int c=in.readInt(),l=in.readInt();Bitmap b=load(new File(f,"edit-"+c+".png"));dir=f;cursor=c;last=l;return b;}}
    static Bitmap load(File f)throws IOException{Bitmap b=BitmapFactory.decodeFile(f.getAbsolutePath());if(b==null)throw new IOException("Project image missing");return b;}
    static Bitmap thumbnail(File f){try(DataInputStream in=new DataInputStream(new AtomicFile(new File(f,"state")).openRead())){int n=in.readInt();File img=new File(f,"edit-"+n+".png");BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;BitmapFactory.decodeFile(img.getAbsolutePath(),o);if(o.outWidth<=0||o.outHeight<=0)return null;o.inSampleSize=1;while(Math.max(o.outWidth,o.outHeight)/o.inSampleSize>256)o.inSampleSize*=2;o.inJustDecodeBounds=false;return BitmapFactory.decodeFile(img.getAbsolutePath(),o);}catch(Exception|OutOfMemoryError e){return null;}}
    Bitmap original()throws IOException{return load(frame(0));}
    Bitmap move(int delta)throws IOException{int n=cursor+delta;if(n<0||n>last||!frame(n).isFile())throw new IOException("History limit reached");Bitmap b=load(frame(n));state(n,last);return b;}
    void remove(File f)throws IOException{File[] files=f.listFiles();if(files!=null)for(File child:files)if(!child.delete())throw new IOException("Cannot delete project file");if(!f.delete())throw new IOException("Cannot delete project");}
}
