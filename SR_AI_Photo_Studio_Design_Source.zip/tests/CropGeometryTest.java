package com.srcreationfarm.photostudio;
import java.util.Random;
public final class CropGeometryTest {
    static int count;
    static void check(boolean ok){count++;if(!ok)throw new AssertionError("Crop assertion "+count);}
    static void bounds(CropGeometry g){int[] p=g.pixels();check(p[0]>=0&&p[1]>=0&&p[2]>=1&&p[3]>=1&&p[0]+p[2]<=g.width&&p[1]+p[3]<=g.height);check(g.left>=-.00001f&&g.top>=-.00001f&&g.right<=1.00001f&&g.bottom<=1.00001f&&g.right>g.left&&g.bottom>g.top);}
    public static void main(String[] args){Random random=new Random(37);for(int[] size:new int[][]{{4000,3000},{3000,4000},{4096,100},{100,4096},{1,1}}){for(float ratio:new float[]{0,1,.8f,1.5f,16/9f,9/16f}){CropGeometry g=new CropGeometry(size[0],size[1]);g.setRatio(ratio);bounds(g);for(int i=0;i<60;i++){int handle=random.nextInt(5);g.drag(handle,random.nextFloat()*2-.5f,random.nextFloat()*2-.5f,random.nextFloat()-.5f,random.nextFloat()-.5f);bounds(g);if(ratio>0){float ar=(g.right-g.left)*g.width/((g.bottom-g.top)*g.height);check(Math.abs(ar-ratio)<.015f);}}}}CropGeometry g=new CropGeometry(100,100);check(g.hit(0,0,.1f,.1f)==0);check(g.hit(.5f,.5f,.1f,.1f)==4);g.drag(3,.6f,.6f,0,0);check(g.pixels()[2]==60&&g.pixels()[3]==60);System.out.println("Crop geometry assertions passed: "+count);}
}
