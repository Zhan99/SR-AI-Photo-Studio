package com.srcreationfarm.photostudio;
public final class PixelMathTest {
    private static int count;
    private static void check(boolean b,String msg){count++;if(!b)throw new AssertionError(msg);}
    public static void main(String[] args){
        int p=0x7f806040;
        for(String t:PixelMath.TOOLS){check(PixelMath.color(p,t,0,5,5,10,10,0)==p,t+" neutral");check((PixelMath.color(p,t,1,0,0,10,10,0)>>>24)==127,t+" alpha");}
        check(PixelMath.clamp(-5)==0,"lower clamp");check(PixelMath.clamp(260)==255,"upper clamp");
        check(PixelMath.color(0xff505050,"Exposure",1,0,0,1,1,0)==0xffffffff,"exposure");
        check(PixelMath.color(0xff808080,"Brightness",-1,0,0,1,1,0)==0xff212121,"brightness");
        int bw=PixelMath.color(0xffff0000,"Black and white",1,0,0,1,1,0);check((bw>>16&255)==(bw&255),"gray");
        check(PixelMath.hsl(0xffff0000,120,0,0)==0xff00ff00,"hue rotate");
        check(PixelMath.hsl(0xff000000,0,1,0)==0xff000000,"black HSL");
        check(PixelMath.hsl(0xffffffff,0,1,0)==0xffffffff,"white HSL");
        int[] f=PixelMath.fit(8000,4000,4096,12_000_000);check(f[0]==4096&&f[1]==2048,"wide resize");
        f=PixelMath.fit(9000,9000,4096,12_000_000);check((long)f[0]*f[1]<=12_000_000,"pixel cap");
        f=PixelMath.fit(100,200,4096,12_000_000);check(f[0]==100&&f[1]==200,"no input upscale");
        f=PixelMath.fit(1,1000000,4096,12_000_000);check(f[0]>=1&&f[1]==4096,"extreme aspect");
        for(String t:PixelMath.TOOLS)for(int v=-100;v<=100;v+=25){int z=PixelMath.color(0x4a00ff80,t,v/100.,7,5,8,6,140);check(z>>>24==0x4a,t+" alpha at "+v);}
        check(PixelMath.sourceOver(0xffff0000,0xff0000ff,0)==0xff0000ff,"mask zero");
        check(PixelMath.sourceOver(0xffff0000,0xff0000ff,1)==0xffff0000,"mask one");
        check(PixelMath.sourceOver(0xffff0000,0,0.5)==0x80ff0000,"transparent alpha");
        check(PixelMath.sourceOver(0xffff0000,0xff0000ff,0.5)==0xff800080,"blend half");
        for(int i=0;i<256;i++)check(PixelMath.curve(i,64,128,192)==i,"identity curve");check(PixelMath.curve(128,32,200,230)==200,"curve midpoint");boolean invalid=false;try{PixelMath.fit(0,1,1,1);}catch(IllegalArgumentException e){invalid=true;}check(invalid,"invalid dimensions");
        System.out.println("PixelMath tests passed: "+count);
    }
}
