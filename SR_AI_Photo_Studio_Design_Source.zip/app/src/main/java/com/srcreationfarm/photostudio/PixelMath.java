package com.srcreationfarm.photostudio;

/** Pure Java color functions, also exercised by the host JVM tests. */
public final class PixelMath {
    private PixelMath() {}
    public static final String[] TOOLS={"Exposure","Brightness","Contrast","Saturation","Highlights","Shadows","Temperature","Tint","Vibrance","Sharpness","Clarity","Dehaze","Blur","Vignette","Grain","RGB gamma","Red gamma","Green gamma","Blue gamma","HSL hue","HSL saturation","HSL lightness","Selective saturation","Noise reduction","Skin smoothing","Cinematic","DSLR","HDR","Vintage","Retro","Neon","Artistic","Sketch","Cartoon","Oil style","Landscape","Black and white","Glitch"};
    public static int clamp(double n){return (int)Math.max(0,Math.min(255,Math.round(n)));}
    public static int pack(int a,double r,double g,double b){return (a<<24)|(clamp(r)<<16)|(clamp(g)<<8)|clamp(b);}
    public static double luma(double r,double g,double b){return .2126*r+.7152*g+.0722*b;}
    public static boolean spatial(String t){return t.equals("Sharpness")||t.equals("Clarity")||t.equals("Blur")||t.equals("Noise reduction")||t.equals("Skin smoothing")||t.equals("Sketch")||t.equals("DSLR")||t.equals("HDR")||t.equals("Cartoon")||t.equals("Oil style")||t.equals("Glitch");}
    public static double mix(double a,double b,double f){return a+(b-a)*f;}
    public static double hue(double r,double g,double b){double max=Math.max(r,Math.max(g,b)),min=Math.min(r,Math.min(g,b)),d=max-min;if(d==0)return 0;double h=max==r?(g-b)/d:max==g?2+(b-r)/d:4+(r-g)/d;return (h*60+360)%360;}
    public static int hsl(int p,double shift,double sat,double light){int a=p>>>24; double r=(p>>16&255)/255.,g=(p>>8&255)/255.,b=(p&255)/255.;double max=Math.max(r,Math.max(g,b)),min=Math.min(r,Math.min(g,b)),d=max-min,l=(max+min)/2,s=d==0?0:d/(1-Math.abs(2*l-1));double h=(hue(r,g,b)+shift+360)%360;s=Math.max(0,Math.min(1,s*(1+sat)));l=Math.max(0,Math.min(1,l+light));double c=(1-Math.abs(2*l-1))*s,x=c*(1-Math.abs((h/60)%2-1)),m=l-c/2;double rr=0,gg=0,bb=0;if(h<60){rr=c;gg=x;}else if(h<120){rr=x;gg=c;}else if(h<180){gg=c;bb=x;}else if(h<240){gg=x;bb=c;}else if(h<300){rr=x;bb=c;}else{rr=c;bb=x;}return pack(a,(rr+m)*255,(gg+m)*255,(bb+m)*255);}
    public static int color(int p,String t,double v,int x,int y,int w,int h,int targetHue){if(v==0)return p;int a=p>>>24;double r=p>>16&255,g=p>>8&255,b=p&255,l=luma(r,g,b),f=0;
        switch(t){
            case "Exposure": f=Math.pow(2,v*2);r*=f;g*=f;b*=f;break;
            case "Brightness":r+=v*95;g+=v*95;b+=v*95;break;
            case "Contrast":f=1+v*.9;r=(r-128)*f+128;g=(g-128)*f+128;b=(b-128)*f+128;break;
            case "Saturation":f=1+v;r=l+(r-l)*f;g=l+(g-l)*f;b=l+(b-l)*f;break;
            case "Vibrance":f=1+v*(1-(Math.max(r,Math.max(g,b))-Math.min(r,Math.min(g,b)))/255);r=l+(r-l)*f;g=l+(g-l)*f;b=l+(b-l)*f;break;
            case "Highlights":f=v*85*Math.pow(l/255,2);r+=f;g+=f;b+=f;break;
            case "Shadows":f=v*85*Math.pow(1-l/255,2);r+=f;g+=f;b+=f;break;
            case "Temperature":r+=v*38;b-=v*38;break;
            case "Tint":r+=v*16;b+=v*16;g-=v*30;break;
            case "Dehaze":f=1+v*.65;r=(r-105)*f+105;g=(g-105)*f+105;b=(b-105)*f+105;break;
            case "Vignette":double dx=2.*x/Math.max(1,w-1)-1,dy=2.*y/Math.max(1,h-1)-1;f=1-v*.55*Math.min(1,(dx*dx+dy*dy)/2);r*=f;g*=f;b*=f;break;
            case "Grain":int n=(x*73856093)^(y*19349663);n^=n>>>13;f=((n&255)-127.5)*v*.45;r+=f;g+=f;b+=f;break;
            case "RGB gamma":case "Red gamma":case "Green gamma":case "Blue gamma":f=Math.pow(2,-v);if(t.equals("RGB gamma")||t.equals("Red gamma"))r=255*Math.pow(r/255,f);if(t.equals("RGB gamma")||t.equals("Green gamma"))g=255*Math.pow(g/255,f);if(t.equals("RGB gamma")||t.equals("Blue gamma"))b=255*Math.pow(b/255,f);break;
            case "HSL hue":return hsl(p,v*180,0,0);
            case "HSL saturation":return hsl(p,0,v,0);
            case "HSL lightness":return hsl(p,0,0,v*.35);
            case "Selective saturation":double dist=Math.abs(hue(r,g,b)-targetHue);dist=Math.min(dist,360-dist);return hsl(p,0,v*Math.max(0,1-dist/65),0);
            case "Cinematic":r=mix(r,r*.94+18,v);g=mix(g,g*.91+8,v);b=mix(b,b*.9+27,v);break;
            case "Vintage":r=mix(r,.393*r+.769*g+.189*b,v);g=mix(g,.349*(p>>16&255)+.686*g+.168*b,v);b=mix(b,.272*(p>>16&255)+.534*(p>>8&255)+.131*b,v);break;
            case "Retro":r=mix(r,r*.77+36,v);g=mix(g,g*.78+24,v);b=mix(b,b*.67+37,v);break;
            case "Neon":r=mix(r,255-r*.65,v);g=mix(g,g*1.4,v);b=mix(b,b*1.5+25,v);break;
            case "Artistic":r=mix(r,Math.round(r/48)*48,v);g=mix(g,Math.round(g/48)*48,v);b=mix(b,Math.round(b/48)*48,v);break;
            case "Landscape":f=1+v*.38;r=l+(r-l)*f;g=l+(g-l)*f+v*6;b=l+(b-l)*f+v*8;break;
            case "Black and white":r=mix(r,l,v);g=mix(g,l,v);b=mix(b,l,v);break;
            default:break;
        }return pack(a,r,g,b);
    }
    public static int curve(int input,int low,int mid,int high){int[] xs={0,64,128,192,255};int[] ys={0,low,mid,high,255};int i=input<64?0:input<128?1:input<192?2:3;return clamp(mix(ys[i],ys[i+1],(input-xs[i])/(double)(xs[i+1]-xs[i])));}
    public static int sourceOver(int foreground,int background,double mask){double a=(foreground>>>24)/255.*Math.max(0,Math.min(1,mask)),b=(background>>>24)/255.,total=a+b*(1-a);if(total<=0)return 0;return pack(clamp(total*255),((foreground>>16&255)*a+(background>>16&255)*b*(1-a))/total,((foreground>>8&255)*a+(background>>8&255)*b*(1-a))/total,((foreground&255)*a+(background&255)*b*(1-a))/total);}
    public static int[] fit(int w,int h,int maxSide,long maxPixels){if(w<1||h<1||maxSide<1||maxPixels<1)throw new IllegalArgumentException();double s=Math.min(1,Math.min((double)maxSide/Math.max(w,h),Math.sqrt((double)maxPixels/((long)w*h))));return new int[]{Math.max(1,(int)Math.floor(w*s)),Math.max(1,(int)Math.floor(h*s))};}
}
