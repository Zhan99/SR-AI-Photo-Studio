package com.srcreationfarm.photostudio;

import android.content.ContentResolver;
import android.graphics.*;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import java.io.*;
import java.nio.FloatBuffer;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.segmentation.Segmentation;
import com.google.mlkit.vision.segmentation.Segmenter;
import com.google.mlkit.vision.segmentation.SegmentationMask;
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions;
import java.util.concurrent.TimeUnit;

final class ImageEngine {
    static final long MAX_PIXELS=Math.max(1_000_000L,Math.min(12_000_000L,Runtime.getRuntime().maxMemory()/24));
    static final int MAX_SIDE=4096;
    static final Paint FILTER=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
    static Bitmap read(ContentResolver cr, Uri uri) throws IOException {
        if(Build.VERSION.SDK_INT>=28){return ImageDecoder.decodeBitmap(ImageDecoder.createSource(cr,uri),(d,i,s)->{int[] f=PixelMath.fit(i.getSize().getWidth(),i.getSize().getHeight(),MAX_SIDE,MAX_PIXELS);d.setTargetSize(f[0],f[1]);d.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);d.setMutableRequired(true);});}
        BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;
        try(InputStream in=cr.openInputStream(uri)){BitmapFactory.decodeStream(in,null,o);}
        if(o.outWidth<1||o.outHeight<1)throw new IOException("Unsupported image");int[] f=PixelMath.fit(o.outWidth,o.outHeight,MAX_SIDE,MAX_PIXELS);int sample=1;while(o.outWidth/sample>f[0]*2L||o.outHeight/sample>f[1]*2L||(long)(o.outWidth/sample)*(o.outHeight/sample)>MAX_PIXELS)sample*=2;
        o.inJustDecodeBounds=false;o.inSampleSize=sample;o.inPreferredConfig=Bitmap.Config.ARGB_8888;
        Bitmap b;try(InputStream in=cr.openInputStream(uri)){b=BitmapFactory.decodeStream(in,null,o);}if(b==null)throw new IOException("Cannot decode image");
        if(b.getWidth()>f[0]||b.getHeight()>f[1]){Bitmap s=Bitmap.createScaledBitmap(b,f[0],f[1],true);if(s!=b)b.recycle();b=s;}
        int ex=1;try(InputStream in=cr.openInputStream(uri)){if(in!=null)ex=new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION,1);}catch(IOException ignored){}
        Matrix m=new Matrix();switch(ex){case 2:m.setScale(-1,1);break;case 3:m.setRotate(180);break;case 4:m.setScale(1,-1);break;case 5:m.setRotate(90);m.postScale(-1,1);break;case 6:m.setRotate(90);break;case 7:m.setRotate(-90);m.postScale(-1,1);break;case 8:m.setRotate(-90);break;default:return b;}
        Bitmap t=Bitmap.createBitmap(b,0,0,b.getWidth(),b.getHeight(),m,true);if(t!=b)b.recycle();return t;
    }
    static Bitmap preview(Bitmap b,int side){int[] f=PixelMath.fit(b.getWidth(),b.getHeight(),side,(long)side*side);return Bitmap.createScaledBitmap(b,f[0],f[1],true);}
    static Bitmap blank(int w,int h,int color){Bitmap b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);b.eraseColor(color);return b;}
    static Bitmap copy(Bitmap b){return b.copy(Bitmap.Config.ARGB_8888,true);}
    static Bitmap adjust(Bitmap src,String tool,double value,int hue){int w=src.getWidth(),h=src.getHeight();Bitmap out=blank(w,h,Color.TRANSPARENT);int[] row=new int[w],prev=new int[w],next=new int[w],dst=new int[w];double[] c=new double[3];boolean spatial=PixelMath.spatial(tool);src.getPixels(prev,0,w,0,0,w,1);src.getPixels(row,0,w,0,0,w,1);
        for(int y=0;y<h;y++){if(spatial)src.getPixels(next,0,w,0,Math.min(h-1,y+1),w,1);for(int x=0;x<w;x++){int p=row[x];if(!spatial||value==0){dst[x]=PixelMath.color(p,tool,value,x,y,w,h,hue);continue;}int left=row[Math.max(0,x-1)],right=row[Math.min(w-1,x+1)],up=prev[x],down=next[x];for(int k=0;k<3;k++){int shift=16-k*8;double a=p>>shift&255,l=left>>shift&255,r=right>>shift&255,u=up>>shift&255,d=down>>shift&255,avg=(l+r+u+d+a*2)/6;switch(tool){case "Sharpness":case "Clarity":case "DSLR":case "HDR":c[k]=a+(a-avg)*value*(tool.equals("Sharpness")?4:2);if(tool.equals("HDR"))c[k]=(c[k]-128)*(1+value*.15)+128;break;case "Blur":case "Noise reduction":case "Skin smoothing":c[k]=PixelMath.mix(a,avg,Math.abs(value));break;case "Sketch":double edge=Math.min(255,Math.abs(l-r)+Math.abs(u-d));c[k]=PixelMath.mix(a,255-edge,Math.abs(value));break;case "Cartoon":case "Oil style":c[k]=PixelMath.mix(a,Math.round(avg/(tool.equals("Cartoon")?40:24))*(tool.equals("Cartoon")?40:24),Math.abs(value));break;case "Glitch":int offset=(int)(Math.abs(value)*Math.max(2,w/70));int idx=Math.max(0,Math.min(w-1,x+(k==0?offset:k==2?-offset:0)));c[k]=row[idx]>>shift&255;break;default:c[k]=a;}}
            dst[x]=PixelMath.pack(p>>>24,c[0],c[1],c[2]);}out.setPixels(dst,0,w,0,y,w,1);if(y+1<h){if(spatial){int[] swap=prev;prev=row;row=next;next=swap;}else src.getPixels(row,0,w,0,y+1,w,1);}}return out;}
    static Bitmap curves(Bitmap b,int channel,int low,int mid,int high){int[] lut=new int[256];for(int i=0;i<256;i++)lut[i]=PixelMath.curve(i,low,mid,high);int w=b.getWidth(),h=b.getHeight();Bitmap out=blank(w,h,0);int[] row=new int[w];for(int y=0;y<h;y++){b.getPixels(row,0,w,0,y,w,1);for(int x=0;x<w;x++){int p=row[x],r=p>>16&255,g=p>>8&255,bl=p&255;row[x]=PixelMath.pack(p>>>24,channel==0||channel==1?lut[r]:r,channel==0||channel==2?lut[g]:g,channel==0||channel==3?lut[bl]:bl);}out.setPixels(row,0,w,0,y,w,1);}return out;}
    static Bitmap transform(Bitmap b,float deg,boolean flipX,boolean flipY){double rad=Math.toRadians(deg),c=Math.abs(Math.cos(rad)),s=Math.abs(Math.sin(rad));int bw=b.getWidth(),bh=b.getHeight();double rw=bw*c+bh*s,rh=bw*s+bh*c;double f=deg%90==0?1:Math.min(1,Math.min((MAX_SIDE-2)/Math.max(rw,rh),Math.sqrt((MAX_PIXELS-8192)/Math.max(1,rw*rh))));Bitmap input=f<1?Bitmap.createScaledBitmap(b,Math.max(1,(int)(bw*f)),Math.max(1,(int)(bh*f)),true):b;try{Matrix m=new Matrix();m.postScale(flipX?-1:1,flipY?-1:1);m.postRotate(deg);Bitmap t=Bitmap.createBitmap(input,0,0,input.getWidth(),input.getHeight(),m,true);return t==input?copy(input):t;}finally{if(input!=b)input.recycle();}}
    static Bitmap crop(Bitmap b,int l,int t,int r,int bot){int w=b.getWidth(),h=b.getHeight();int x=w*l/100,y=h*t/100;int cw=Math.max(1,w-x-w*r/100),ch=Math.max(1,h-y-h*bot/100);Bitmap z=Bitmap.createBitmap(b,x,y,cw,ch);return z==b?copy(b):z;}
    static Bitmap resize(Bitmap b,int w,int h){if(w<1||h<1||w>MAX_SIDE||h>MAX_SIDE||(long)w*h>MAX_PIXELS)throw new IllegalArgumentException("Maximum 4096 px per side / 12 MP");Bitmap t=Bitmap.createScaledBitmap(b,w,h,true);return t==b?copy(b):t;}
    static Bitmap perspective(Bitmap b,float horizontal,float vertical){int w=b.getWidth(),h=b.getHeight();float x=w*horizontal*.3f,y=h*vertical*.3f;float[] from={0,0,w,0,w,h,0,h},to={Math.max(0,x),Math.max(0,y),w+Math.min(0,x),Math.max(0,-y),w-Math.max(0,x),h+Math.min(0,y),Math.max(0,-x),h-Math.max(0,y)};Matrix m=new Matrix();if(!m.setPolyToPoly(from,0,to,0,4))throw new IllegalArgumentException("Invalid perspective");Bitmap out=blank(w,h,0);new Canvas(out).drawBitmap(b,m,FILTER);return out;}
    static Bitmap segment(Bitmap b,Integer bg,Bitmap background,boolean portraitBlur) throws Exception {
        Bitmap small=preview(b,1024);Segmenter segmenter=Segmentation.getClient(new SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build());
        Bitmap out=null,tiny=null;boolean done=false;try {
            SegmentationMask result=Tasks.await(segmenter.process(InputImage.fromBitmap(small,0)),45,TimeUnit.SECONDS);int mw=result.getWidth(),mh=result.getHeight();FloatBuffer data=result.getBuffer().duplicate().order(result.getBuffer().order()).asFloatBuffer();data.rewind();float[] conf=new float[mw*mh];data.get(conf);
            int w=b.getWidth(),h=b.getHeight();out=blank(w,h,bg==null?0:bg);Canvas c=new Canvas(out);Rect dest=new Rect(0,0,w,h);if(background!=null)c.drawBitmap(background,null,dest,FILTER);if(portraitBlur){tiny=preview(b,80);c.drawBitmap(tiny,null,dest,FILTER);}
            int[] src=new int[w],dst=new int[w];for(int y=0;y<h;y++){b.getPixels(src,0,w,0,y,w,1);out.getPixels(dst,0,w,0,y,w,1);double yy=(double)y*Math.max(0,mh-1)/Math.max(1,h-1);int y0=(int)yy,y1=Math.min(mh-1,y0+1);for(int x=0;x<w;x++){double xx=(double)x*Math.max(0,mw-1)/Math.max(1,w-1);int x0=(int)xx,x1=Math.min(mw-1,x0+1);double confidence=PixelMath.mix(PixelMath.mix(conf[y0*mw+x0],conf[y0*mw+x1],xx-x0),PixelMath.mix(conf[y1*mw+x0],conf[y1*mw+x1],xx-x0),yy-y0);double alpha=Math.max(0,Math.min(1,(confidence-.15)/.7));dst[x]=PixelMath.sourceOver(src[x],dst[x],alpha);}out.setPixels(dst,0,w,0,y,w,1);}
            done=true;return out;
        }finally{segmenter.close();if(small!=b)small.recycle();if(tiny!=null&&tiny!=b)tiny.recycle();if(!done&&out!=null)out.recycle();}
    }
    static Bitmap overlay(Bitmap b,Bitmap top,int opacity,String blend,float scale,float x,float y){Bitmap out=copy(b);Canvas c=new Canvas(out);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);p.setAlpha(opacity);if(blend.equals("Multiply"))p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.MULTIPLY));else if(blend.equals("Screen"))p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SCREEN));else if(blend.equals("Add"))p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.ADD));float tw=b.getWidth()*scale,th=tw*top.getHeight()/top.getWidth(),cx=b.getWidth()*x,cy=b.getHeight()*y;c.drawBitmap(top,null,new RectF(cx-tw/2,cy-th/2,cx+tw/2,cy+th/2),p);return out;}
    static Bitmap text(Bitmap b,String text,Typeface font,int color,float size,float x,float y,boolean stroke,boolean shadow,boolean curved,boolean gradient){Bitmap out=copy(b);Canvas c=new Canvas(out);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setTypeface(font);p.setTextSize(b.getWidth()*size);p.setTextAlign(Paint.Align.CENTER);float cx=b.getWidth()*x,cy=b.getHeight()*y;if(shadow)p.setShadowLayer(p.getTextSize()*.06f,2,3,Color.BLACK);Path path=new Path();path.moveTo(cx-b.getWidth()*.45f,cy);path.quadTo(cx,cy-p.getTextSize()*2,cx+b.getWidth()*.45f,cy);if(stroke){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(1,p.getTextSize()*.06f));p.setColor(Color.BLACK);if(curved)c.drawTextOnPath(text,path,0,0,p);else c.drawText(text,cx,cy,p);}p.setStyle(Paint.Style.FILL);p.setColor(color);if(gradient)p.setShader(new LinearGradient(cx,cy-p.getTextSize(),cx,cy,new int[]{color,Color.WHITE},null,Shader.TileMode.CLAMP));if(curved)c.drawTextOnPath(text,path,0,0,p);else c.drawText(text,cx,cy,p);return out;}
    static Bitmap frame(Bitmap b,int color,int amount){Bitmap out=copy(b);if(amount<=0)return out;Canvas c=new Canvas(out);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setStyle(Paint.Style.STROKE);p.setColor(color);float width=Math.min(b.getWidth(),b.getHeight())*amount/100f;p.setStrokeWidth(width);c.drawRect(width/2,width/2,b.getWidth()-width/2,b.getHeight()-width/2,p);return out;}
    static Bitmap collage(Bitmap[] images,int w,int h){Bitmap out=blank(w,h,0xffeeeeee);Canvas c=new Canvas(out);int cols=images.length==1?1:2,rows=(images.length+cols-1)/cols;for(int i=0;i<images.length;i++){float x=(i%cols)*w/(float)cols,y=(i/cols)*h/(float)rows;RectF d=new RectF(x+8,y+8,x+w/(float)cols-8,y+h/(float)rows-8);Bitmap b=images[i];float ratio=Math.max(d.width()/b.getWidth(),d.height()/b.getHeight());float ww=b.getWidth()*ratio,hh=b.getHeight()*ratio;int save=c.save();c.clipRect(d);c.drawBitmap(b,null,new RectF(d.centerX()-ww/2,d.centerY()-hh/2,d.centerX()+ww/2,d.centerY()+hh/2),FILTER);c.restoreToCount(save);}return out;}
}
