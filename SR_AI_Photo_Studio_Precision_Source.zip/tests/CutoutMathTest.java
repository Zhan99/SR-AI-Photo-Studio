package com.srcreationfarm.photostudio;
import java.util.*;
public final class CutoutMathTest {
    static int count;static void check(boolean b,String msg){count++;if(!b)throw new AssertionError(msg);}
    static int u(byte b){return b&255;}
    public static void main(String[] args){
        byte[] a=CutoutMath.confidence(new float[]{0,1,Float.NaN,.5f},2,2,2,2);check(u(a[0])==0&&u(a[1])==255&&u(a[2])==0&&u(a[3])==128,"confidence conversion");
        check(CutoutMath.sample(new byte[]{0,(byte)255},2,1,.5f,0)==128,"bilinear midpoint");
        byte[] base={(byte)255,(byte)128,0},manual={-127,0,127};byte[] result=CutoutMath.refine(base,manual,3,1,50,70,0,0,false,false);check(u(result[0])==0&&u(result[1])==128&&u(result[2])==255,"brush alpha override");
        result=CutoutMath.refine(base,new byte[3],3,1,50,70,0,0,true,false);check(u(result[0])==0&&u(result[1])==127&&u(result[2])==255,"invert");
        int[] color={0xff00ff00,0xffff0000,0xff00ff00};result=CutoutMath.colorMask(color,3,1,color[0],0,.2f,.1f,true);check(u(result[0])==0&&u(result[1])==255&&u(result[2])==255,"connected only");result=CutoutMath.colorMask(color,3,1,color[0],0,.2f,.1f,false);check(u(result[2])==0,"global key");
        byte[] edits=new byte[101*101];CutoutMath.stroke(edits,101,101,new float[]{.2f,.5f,.8f,.5f},.1f,1,1,false);for(int x=20;x<=80;x++)check(edits[50*101+x]==-127,"stroke continuity");check(edits[0]==0,"outside unchanged");CutoutMath.stroke(edits,101,101,new float[]{.5f,.5f},.1f,1,1,true);check(edits[50*101+50]==127,"restore");check(edits[50*101+20]==-127,"other stroke remains");
        byte[] soft=new byte[101*101];CutoutMath.stroke(soft,101,101,new float[]{.5f,.5f},.2f,0,1,false);check(soft[50*101+50]==-127,"soft center");check(soft[50*101+56]<0&&soft[50*101+56]>-127,"soft edge");
        byte[] guideMask={0,(byte)128,(byte)255};int[] guideColors={0xff000000,0xffffffff,0xffffffff};byte[] guided=CutoutMath.guided(guideMask,guideColors,3,1);check(u(guided[0])==0&&u(guided[2])==255&&u(guided[1])>128,"color guided uncertain edge");
        byte[] fused=CutoutMath.fuseMirror(new byte[]{0,20,(byte)200,(byte)255},new byte[]{(byte)255,(byte)200,20,0},4,1);check(Arrays.equals(fused,new byte[]{0,20,(byte)200,(byte)255}),"mirror alignment");
        check(u(CutoutMath.fuseMirror(new byte[]{0},new byte[]{(byte)255},1,1)[0])==128,"mirror average");
        byte[] trimap={0,0,(byte)128,(byte)255,(byte)255};int[] bright={0xff000000,0xff000000,0xffffffff,0xffffffff,0xffffffff};int[] dark={0xff000000,0xff000000,0xff000000,0xffffffff,0xffffffff};byte[] refined=CutoutMath.detail(trimap,bright,5,1);check(u(refined[2])>128,"foreground edge evidence");check(u(CutoutMath.detail(trimap,dark,5,1)[2])<128,"background edge evidence");check(refined[0]==0&&u(refined[4])==255,"preserve confident areas");check(Arrays.equals(trimap,CutoutMath.detail(trimap,new int[5],5,1)),"equal color evidence");
        check(Arrays.equals(new byte[]{-127,0,127},CutoutMath.resizeSigned(new byte[]{-127,0,127},3,1,3,1)),"signed identity");check(Arrays.equals(new byte[]{-127,127},CutoutMath.resizeSigned(new byte[]{-127,-127,127,127},4,1,2,1)),"signed downsample");
        Random rng=new Random(327);for(int i=0;i<150;i++){int w=1+rng.nextInt(22),h=1+rng.nextInt(22),r=1+rng.nextInt(25);byte[] src=new byte[w*h];rng.nextBytes(src);for(boolean grow:new boolean[]{false,true}){byte[] got=CutoutMath.morph(src,w,h,r,grow);for(int y=0;y<h;y++)for(int x=0;x<w;x++){int expected=grow?0:255;for(int yy=Math.max(0,y-r);yy<=Math.min(h-1,y+r);yy++)for(int xx=Math.max(0,x-r);xx<=Math.min(w-1,x+r);xx++)expected=grow?Math.max(expected,u(src[yy*w+xx])):Math.min(expected,u(src[yy*w+xx]));check(u(got[y*w+x])==expected,"morph reference");}}byte[] blurred=CutoutMath.box(src,w,h,r);for(int y=0;y<h;y++)for(int x=0;x<w;x++){int sum=0,n=2*r+1;for(int yy=y-r;yy<=y+r;yy++){int hs=0;for(int xx=x-r;xx<=x+r;xx++)hs+=u(src[CutoutMath.clamp(yy,0,h-1)*w+CutoutMath.clamp(xx,0,w-1)]);sum+=(hs+n/2)/n;}check(u(blurred[y*w+x])==(sum+n/2)/n,"blur reference");}}
        System.out.println("CutoutMath: "+count+" assertions passed");
    }
}
