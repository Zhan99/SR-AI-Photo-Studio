package com.srcreationfarm.photostudio;

/** Pure Java alpha-mask operations. No neural inference is performed here. */
final class CutoutMath {
    static int clamp(int n,int lo,int hi){return Math.max(lo,Math.min(hi,n));}
    static float unit(float n){return Float.isFinite(n)?Math.max(0,Math.min(1,n)):0;}
    static int u(byte b){return b&255;}
    static float smooth(float a,float b,float v){if(b<=a)return v>=a?1:0;float t=unit((v-a)/(b-a));return t*t*(3-2*t);}
    static int sample(byte[] a,int w,int h,float x,float y){
        x=Math.max(0,Math.min(w-1,x));y=Math.max(0,Math.min(h-1,y));int x0=(int)x,y0=(int)y,x1=Math.min(w-1,x0+1),y1=Math.min(h-1,y0+1);float fx=x-x0,fy=y-y0;
        float top=u(a[y0*w+x0])*(1-fx)+u(a[y0*w+x1])*fx,bot=u(a[y1*w+x0])*(1-fx)+u(a[y1*w+x1])*fx;
        return Math.round(top*(1-fy)+bot*fy);
    }
    static byte[] confidence(float[] raw,int sw,int sh,int w,int h){
        if(sw<1||sh<1||raw.length!=sw*sh||w<1||h<1)throw new IllegalArgumentException("Invalid mask dimensions");
        byte[] src=new byte[raw.length],out=new byte[w*h];for(int i=0;i<raw.length;i++)src[i]=(byte)Math.round(unit(raw[i])*255);
        for(int y=0;y<h;y++)for(int x=0;x<w;x++)out[y*w+x]=(byte)sample(src,sw,sh,(x+.5f)*sw/w-.5f,(y+.5f)*sh/h-.5f);return out;
    }
    /** Fuse a normal prediction with a horizontally mirrored prediction, aligned to the original. */
    static byte[] fuseMirror(byte[] normal,byte[] mirrored,int w,int h){
        if(normal.length!=w*h||mirrored.length!=normal.length)throw new IllegalArgumentException("Mask dimensions");
        byte[] out=new byte[normal.length];for(int y=0;y<h;y++)for(int x=0;x<w;x++){int i=y*w+x;out[i]=(byte)((u(normal[i])+u(mirrored[y*w+w-1-x])+1)/2);}return out;
    }
    /** Local trimap refinement. Only uncertain pixels with both foreground and background evidence change. */
    static byte[] detail(byte[] a,int[] colors,int w,int h){
        if(a.length!=w*h||colors.length!=a.length)throw new IllegalArgumentException("Guide dimensions");
        byte[] out=a.clone();int[] radii={2,5,10};
        for(int y=0;y<h;y++)for(int x=0;x<w;x++){int i=y*w+x,v=u(a[i]);if(v<16||v>239)continue;int p=colors[i];int fg=Integer.MAX_VALUE,bg=Integer.MAX_VALUE;
            for(int r:radii){for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){if(dx==0&&dy==0)continue;int xx=x+dx*r,yy=y+dy*r;if(xx<0||xx>=w||yy<0||yy>=h)continue;int j=yy*w+xx,q=colors[j],av=u(a[j]);int dr=(p>>16&255)-(q>>16&255),dg=(p>>8&255)-(q>>8&255),db=(p&255)-(q&255);int d=dr*dr+dg*dg+db*db+32*r*r;if(av>=240)fg=Math.min(fg,d);else if(av<=15)bg=Math.min(bg,d);}}
            if(fg==Integer.MAX_VALUE||bg==Integer.MAX_VALUE)continue;float evidence=(bg+256f)/(fg+bg+512f);float reliability=Math.abs(fg-bg)/(fg+bg+512f);out[i]=(byte)clamp(Math.round(v+(255*evidence-v)*reliability*.75f),0,255);
        }return out;
    }
    static byte[] resizeSigned(byte[] src,int w,int h,int nw,int nh){if(src.length!=w*h||w<1||h<1||nw<1||nh<1)throw new IllegalArgumentException("Mask dimensions");byte[] out=new byte[nw*nh];for(int y=0;y<nh;y++)for(int x=0;x<nw;x++)out[y*nw+x]=src[Math.min(h-1,(int)((y+.5)*h/nh))*w+Math.min(w-1,(int)((x+.5)*w/nw))];return out;}
    static float distance(int p,int key){float r=(p>>16&255)-(key>>16&255),g=(p>>8&255)-(key>>8&255),b=(p&255)-(key&255);return (float)Math.sqrt((r*r+g*g+b*b)/3f)/255f;}
    static byte[] colorMask(int[] pixels,int w,int h,int key,int seed,float tolerance,float softness,boolean connected){
        byte[] out=new byte[pixels.length];float t=unit(tolerance),s=Math.max(.004f,unit(softness));
        for(int i=0;i<out.length;i++)out[i]=(byte)Math.round(255*smooth(Math.max(0,t-s/2),Math.min(1,t+s/2),distance(pixels[i],key)));
        if(!connected)return out;
        // Only background-like pixels connected to the selected seed. Four-neighbor flood fill.
        if(seed<0||seed>=out.length)return out;boolean[] seen=new boolean[out.length];int[] q=new int[out.length];int head=0,tail=0;seen[seed]=true;q[tail++]=seed;
        while(head<tail){int i=q[head++],x=i%w,y=i/w;for(int d=0;d<4;d++){int j=d==0?(x>0?i-1:-1):d==1?(x+1<w?i+1:-1):d==2?(y>0?i-w:-1):(y+1<h?i+w:-1);if(j>=0&&!seen[j]&&u(out[j])<255){seen[j]=true;q[tail++]=j;}}}
        for(int i=0;i<out.length;i++)if(!seen[i])out[i]=(byte)255;return out;
    }
    static byte[] refine(byte[] base,byte[] manual,int w,int h,int threshold,int softness,int edge,int feather,boolean invert,boolean thresholdEnabled){return refine(base,manual,w,h,threshold,softness,edge,feather,invert,thresholdEnabled,null);}
    static byte[] refine(byte[] base,byte[] manual,int w,int h,int threshold,int softness,int edge,int feather,boolean invert,boolean thresholdEnabled,int[] guide){
        if(base.length!=w*h||manual.length!=base.length)throw new IllegalArgumentException("Mask shape mismatch");
        byte[] a=new byte[base.length];float t=threshold/100f,s=softness/100f;
        for(int i=0;i<a.length;i++){float v=u(base[i])/255f;if(thresholdEnabled)v=smooth(Math.max(0,t-s/2),Math.min(1,t+s/2),v);if(invert)v=1-v;a[i]=(byte)Math.round(v*255);}
        if(edge!=0){int r=Math.min(24,Math.abs(edge));a=morph(a,w,h,r,edge>0);}
        if(feather>0){int r=Math.min(24,feather);a=box(a,w,h,r);}
        if(guide!=null)a=guided(a,guide,w,h);
        // Apply brush overrides after edge refinement; positive restores, negative erases.
        for(int i=0;i<a.length;i++){int m=manual[i],v=u(a[i]);a[i]=(byte)clamp(Math.round(m>=0?v+(255-v)*(m/127f):v*(1+m/127f)),0,255);}return a;
    }
    // Edge-aware local filtering of uncertain alpha; nearby colors receive more weight.
    // It is not a hair matting model and does not invent missing details.
    static byte[] guided(byte[] a,int[] colors,int w,int h){
        if(colors.length!=a.length)throw new IllegalArgumentException("Guide dimensions");byte[] out=a.clone();
        for(int y=0;y<h;y++)for(int x=0;x<w;x++){int i=y*w+x,v=u(a[i]);if(v==0||v==255)continue;int p=colors[i];float sum=2*v,weights=2;
            for(int yy=Math.max(0,y-1);yy<=Math.min(h-1,y+1);yy++)for(int xx=Math.max(0,x-1);xx<=Math.min(w-1,x+1);xx++){if(xx==x&&yy==y)continue;int j=yy*w+xx,q=colors[j],d=Math.abs((p>>16&255)-(q>>16&255))+Math.abs((p>>8&255)-(q>>8&255))+Math.abs((p&255)-(q&255));float f=1f/(1f+d*d/3600f);if(xx!=x&&yy!=y)f*=.7f;sum+=f*u(a[j]);weights+=f;}out[i]=(byte)Math.round(sum/weights);
        }return out;
    }
    static byte[] morph(byte[] a,int w,int h,int r,boolean grow){
        byte[] b=new byte[a.length],c=new byte[a.length];int[] q=new int[Math.max(w,h)];
        for(int y=0;y<h;y++)extrema(a,b,y*w,1,w,r,grow,q);
        for(int x=0;x<w;x++)extrema(b,c,x,w,h,r,grow,q);return c;
    }
    private static void extrema(byte[] a,byte[] b,int offset,int stride,int n,int r,boolean grow,int[] q){
        int head=0,tail=0,next=0;for(int i=0;i<n;i++){int end=Math.min(n-1,i+r);while(next<=end){int v=u(a[offset+next*stride]);while(tail>head&&(grow?u(a[offset+q[tail-1]*stride])<=v:u(a[offset+q[tail-1]*stride])>=v))tail--;q[tail++]=next++;}while(head<tail&&q[head]<i-r)head++;b[offset+i*stride]=a[offset+q[head]*stride];}
    }
    static byte[] box(byte[] a,int w,int h,int r){byte[] b=new byte[a.length],c=new byte[a.length];int count=2*r+1;for(int y=0;y<h;y++){int sum=0;for(int k=-r;k<=r;k++)sum+=u(a[y*w+clamp(k,0,w-1)]);for(int x=0;x<w;x++){b[y*w+x]=(byte)((sum+count/2)/count);sum+=u(a[y*w+clamp(x+r+1,0,w-1)])-u(a[y*w+clamp(x-r,0,w-1)]);}}for(int x=0;x<w;x++){int sum=0;for(int k=-r;k<=r;k++)sum+=u(b[clamp(k,0,h-1)*w+x]);for(int y=0;y<h;y++){c[y*w+x]=(byte)((sum+count/2)/count);sum+=u(b[clamp(y+r+1,0,h-1)*w+x])-u(b[clamp(y-r,0,h-1)*w+x]);}}return c;}
    static void stroke(byte[] manual,int w,int h,float[] points,float diameter,float hardness,float strength,boolean restore){
        if(points.length<2||strength<=0)return;float radius=Math.max(.75f,diameter*Math.min(w,h)/2),hard=unit(hardness),power=unit(strength);byte[] coverage=new byte[manual.length];
        float lastX=points[0]*(w-1),lastY=points[1]*(h-1);dab(coverage,w,h,lastX,lastY,radius,hard);
        for(int k=2;k+1<points.length;k+=2){float x=points[k]*(w-1),y=points[k+1]*(h-1);int steps=Math.max(1,(int)Math.ceil(Math.hypot(x-lastX,y-lastY)/Math.max(.7f,radius*.4f)));for(int j=1;j<=steps;j++){float f=j/(float)steps;dab(coverage,w,h,lastX+(x-lastX)*f,lastY+(y-lastY)*f,radius,hard);}lastX=x;lastY=y;}
        for(int i=0;i<manual.length;i++){float a=u(coverage[i])/255f*power;if(a>0)manual[i]=(byte)clamp(Math.round(manual[i]+((restore?127:-127)-manual[i])*a),-127,127);}
    }
    private static void dab(byte[] a,int w,int h,float cx,float cy,float r,float hard){float rr=r*r;for(int y=Math.max(0,(int)Math.floor(cy-r));y<=Math.min(h-1,(int)Math.ceil(cy+r));y++)for(int x=Math.max(0,(int)Math.floor(cx-r));x<=Math.min(w-1,(int)Math.ceil(cx+r));x++){float dx=x-cx,dy=y-cy,d2=dx*dx+dy*dy;if(d2>rr)continue;float d=(float)Math.sqrt(d2)/r;int v=Math.round(255*(1-smooth(hard,1,d)));int i=y*w+x;if(v>u(a[i]))a[i]=(byte)v;}}
    private CutoutMath(){}
}
