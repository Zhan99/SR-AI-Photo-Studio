package com.srcreationfarm.photostudio;

import android.graphics.*;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.segmentation.*;
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions;
import java.nio.FloatBuffer;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

final class CutoutEngine {
    static final int AUTO=0,MANUAL=1,KEY=2;
    static final class Mask {
        final int w,h,mode;final byte[] base;final int[] colors; byte[] lastManual,lastMask; String lastKey; Bitmap alphaBitmap; Mask quick; byte[] quickManualSource,quickManual;
        Mask(int w,int h,int mode,byte[] base,int[] colors){this.w=w;this.h=h;this.mode=mode;this.base=base;this.colors=colors;}
    }
    static Mask prepare(Bitmap image,int mode,boolean precise) throws Exception {
        Bitmap small=ImageEngine.preview(image,mode==AUTO&&precise?1536:1024);int w=small.getWidth(),h=small.getHeight();Segmenter s=null;Bitmap flipped=null;
        try{byte[] base;int[] colors=null;if(mode==AUTO){s=Segmentation.getClient(new SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build());base=predict(s,small,w,h);if(precise){Matrix matrix=new Matrix();matrix.setScale(-1,1);flipped=Bitmap.createBitmap(small,0,0,w,h,matrix,true);base=CutoutMath.fuseMirror(base,predict(s,flipped,w,h),w,h);}colors=new int[w*h];small.getPixels(colors,0,w,0,0,w,h);if(precise)base=CutoutMath.detail(base,colors,w,h);}else{base=new byte[w*h];Arrays.fill(base,(byte)255);if(mode==KEY){colors=new int[w*h];small.getPixels(colors,0,w,0,0,w,h);}}return new Mask(w,h,mode,base,colors);}finally{if(s!=null)s.close();if(flipped!=null&&flipped!=small)flipped.recycle();if(small!=image)small.recycle();}
    }
    private static byte[] predict(Segmenter s,Bitmap b,int w,int h) throws Exception {SegmentationMask m=Tasks.await(s.process(InputImage.fromBitmap(b,0)),45,TimeUnit.SECONDS);FloatBuffer f=m.getBuffer().duplicate().order(m.getBuffer().order()).asFloatBuffer();f.rewind();float[] raw=new float[Math.multiplyExact(m.getWidth(),m.getHeight())];f.get(raw);return CutoutMath.confidence(raw,m.getWidth(),m.getHeight(),w,h);}
    static void release(Mask m){if(m.quick!=null){release(m.quick);m.quick=null;}m.quickManualSource=null;m.quickManual=null;if(m.alphaBitmap!=null){m.alphaBitmap.recycle();m.alphaBitmap=null;}m.lastManual=null;m.lastMask=null;m.lastKey=null;}
    private static byte[] refined(Mask m,byte[] manual,Options o){String k=o.threshold+":"+o.softness+":"+o.edge+":"+o.feather+":"+o.invert+":"+o.guided+":"+o.seed+":"+o.key+":"+o.tolerance+":"+o.keySoft+":"+o.connected;
        if(manual==m.lastManual&&k.equals(m.lastKey)&&m.lastMask!=null)return m.lastMask;
        byte[] base=m.mode==KEY&&o.seed>=0?CutoutMath.colorMask(m.colors,m.w,m.h,o.key,o.seed,o.tolerance/100f,o.keySoft/100f,o.connected):m.base;
        byte[] result=CutoutMath.refine(base,manual,m.w,m.h,o.threshold,o.softness,o.edge,o.feather,o.invert,m.mode==AUTO,o.guided?m.colors:null);
        if(m.alphaBitmap!=null){m.alphaBitmap.recycle();m.alphaBitmap=null;}m.lastManual=manual;m.lastKey=k;m.lastMask=result;return result;
    }
    private static Bitmap alphaBitmap(Mask m,byte[] mask){if(m.alphaBitmap==null){Bitmap a=Bitmap.createBitmap(m.w,m.h,Bitmap.Config.ARGB_8888);int[] row=new int[m.w];for(int y=0;y<m.h;y++){for(int x=0;x<m.w;x++)row[x]=(mask[y*m.w+x]&255)<<24;a.setPixels(row,0,m.w,0,y,m.w,1);}m.alphaBitmap=a;}return m.alphaBitmap;}
    static final class Options {
        int threshold=50,softness=70,edge,feather=1,key,seed=-1,tolerance=20,keySoft=12,background=0,color=Color.WHITE,color2=0xff8061df,angle=90,blur=55,fit=0,zoom=100,x=50,y=50,view=0;boolean invert,connected,despill,guided,fast;Bitmap photo;
    }
    static Bitmap render(Bitmap src,Mask m,byte[] manual,Options o){
        if(o.fast&&Math.max(m.w,m.h)>480){Mask original=m;if(m.quick==null){int[] size=PixelMath.fit(m.w,m.h,480,480L*480);int qw=size[0],qh=size[1];byte[] base=new byte[qw*qh];int[] colors=m.colors==null?null:new int[base.length];for(int y=0;y<qh;y++)for(int x=0;x<qw;x++){float sx=(x+.5f)*m.w/qw-.5f,sy=(y+.5f)*m.h/qh-.5f;int i=y*qw+x;base[i]=(byte)CutoutMath.sample(m.base,m.w,m.h,sx,sy);if(colors!=null)colors[i]=m.colors[CutoutMath.clamp(Math.round(sy),0,m.h-1)*m.w+CutoutMath.clamp(Math.round(sx),0,m.w-1)];}m.quick=new Mask(qw,qh,m.mode,base,colors);}
            m=m.quick;if(original.quickManualSource!=manual){original.quickManual=CutoutMath.resizeSigned(manual,original.w,original.h,m.w,m.h);original.quickManualSource=manual;}manual=original.quickManual;
            float ratio=Math.max(m.w,m.h)/(float)Math.max(original.w,original.h);o.edge=Math.round(o.edge*ratio);o.feather=Math.round(o.feather*ratio);if(o.seed>=0){int sx=o.seed%original.w,sy=o.seed/original.w;o.seed=Math.min(m.h-1,sy*m.h/original.h)*m.w+Math.min(m.w-1,sx*m.w/original.w);}
        }
        byte[] mask=refined(m,manual,o);
        int w=src.getWidth(),h=src.getHeight();Bitmap out=ImageEngine.blank(w,h,Color.TRANSPARENT);Bitmap tiny=null;boolean ok=false;
        try{Canvas c=new Canvas(out);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
            if(o.view==0){switch(o.background){case 1:out.eraseColor(o.color);break;case 2:double rad=Math.toRadians(o.angle);float dx=(float)Math.cos(rad),dy=(float)Math.sin(rad),r=(Math.abs(dx)*w+Math.abs(dy)*h)/2f;p.setShader(new LinearGradient(w/2f-dx*r,h/2f-dy*r,w/2f+dx*r,h/2f+dy*r,o.color,o.color2,Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);break;case 3:if(o.photo!=null){out.eraseColor(o.color);drawPhoto(c,p,o.photo,w,h,o);}break;case 4:if(o.blur>0){tiny=ImageEngine.preview(src,Math.max(8,Math.round(600f/(1+o.blur*.21f))));c.drawBitmap(tiny,null,new Rect(0,0,w,h),p);}else c.drawBitmap(src,0,0,p);break;default:break;}}
            // Fast software Canvas compositing; retain the exact pixel path for color decontamination and diagnostics.
            if((long)w*h<=1_500_000&&o.view==0&&!(o.despill&&m.mode==KEY&&o.seed>=0)){
                Bitmap alpha=alphaBitmap(m,mask);int layer=c.saveLayer(0,0,w,h,null);c.drawBitmap(src,null,new Rect(0,0,w,h),p);p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));c.drawBitmap(alpha,null,new Rect(0,0,w,h),p);p.setXfermode(null);c.restoreToCount(layer);ok=true;return out;
            }
            int[] row=new int[w],dst=new int[w];for(int y=0;y<h;y++){src.getPixels(row,0,w,0,y,w,1);out.getPixels(dst,0,w,0,y,w,1);float my=(y+.5f)*m.h/h-.5f;for(int x=0;x<w;x++){int a=CutoutMath.sample(mask,m.w,m.h,(x+.5f)*m.w/w-.5f,my),fg=row[x];float alpha=a/255f;if(o.view==1){int v=Math.round(a*(fg>>>24)/255f);dst[x]=0xff000000|v<<16|v<<8|v;}else if(o.view==2){dst[x]=PixelMath.sourceOver(0xffff355e,fg,(1-alpha)*.6);}else{if(o.despill&&m.mode==KEY&&o.seed>=0&&a>0&&a<255)fg=decontaminate(fg,o.key,alpha);dst[x]=PixelMath.sourceOver(fg,dst[x],alpha);}}out.setPixels(dst,0,w,0,y,w,1);}ok=true;return out;
        }finally{if(tiny!=null&&tiny!=src)tiny.recycle();if(!ok)out.recycle();}
    }
    private static void drawPhoto(Canvas c,Paint p,Bitmap b,int w,int h,Options o){float z=o.zoom/100f;float dw,dh;if(o.fit==2){dw=w*z;dh=h*z;}else{float scale=(o.fit==0?Math.max(w/(float)b.getWidth(),h/(float)b.getHeight()):Math.min(w/(float)b.getWidth(),h/(float)b.getHeight()))*z;dw=b.getWidth()*scale;dh=b.getHeight()*scale;}float left=(w-dw)*o.x/100f,top=(h-dh)*o.y/100f;c.drawBitmap(b,null,new RectF(left,top,left+dw,top+dh),p);}
    private static int decontaminate(int fg,int key,float a){float blend=(1-a)*.45f,denom=1-blend;int r=CutoutMath.clamp(Math.round(((fg>>16&255)-blend*(key>>16&255))/denom),0,255),g=CutoutMath.clamp(Math.round(((fg>>8&255)-blend*(key>>8&255))/denom),0,255),b=CutoutMath.clamp(Math.round(((fg&255)-blend*(key&255))/denom),0,255);return (fg&0xff000000)|r<<16|g<<8|b;}
    private CutoutEngine(){}
}
