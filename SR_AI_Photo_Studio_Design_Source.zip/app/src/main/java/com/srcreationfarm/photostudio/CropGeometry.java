package com.srcreationfarm.photostudio;

/** Normalized crop rectangle. Fixed ratios are expressed in image pixels. */
final class CropGeometry {
    final int width,height;
    float left,top,right,bottom;
    private float ratio;
    CropGeometry(int width,int height){if(width<1||height<1)throw new IllegalArgumentException();this.width=width;this.height=height;reset();}
    void reset(){left=top=0;right=bottom=1;if(ratio>0)setRatio(ratio);}
    void setRatio(float value){ratio=Math.max(0,value);if(ratio==0)return;float r=ratio*height/width;float w=Math.min(1,r),h=Math.min(1,1/r);left=(1-w)/2;right=left+w;top=(1-h)/2;bottom=top+h;}
    int hit(float x,float y,float rx,float ry){float[] xx={left,right,left,right},yy={top,top,bottom,bottom};int best=-1;float distance=Float.MAX_VALUE;for(int i=0;i<4;i++){float dx=(x-xx[i])/Math.max(.00001f,rx),dy=(y-yy[i])/Math.max(.00001f,ry);float d=dx*dx+dy*dy;if(d<=1&&d<distance){best=i;distance=d;}}if(best>=0)return best;return x>=left&&x<=right&&y>=top&&y<=bottom?4:-1;}
    void drag(int handle,float x,float y,float dx,float dy){if(handle==4){float w=right-left,h=bottom-top;left=clamp(left+dx,0,1-w);top=clamp(top+dy,0,1-h);right=left+w;bottom=top+h;return;}if(handle<0||handle>3)return;boolean l=(handle&1)==0,t=handle<2;float ax=l?right:left,ay=t?bottom:top;float maxW=l?ax:1-ax,maxH=t?ay:1-ay;float minW=Math.min(maxW,Math.max(1f/width,.025f)),minH=Math.min(maxH,Math.max(1f/height,.025f));float w=clamp(l?ax-x:x-ax,minW,maxW),h=clamp(t?ay-y:y-ay,minH,maxH);if(ratio>0){float r=ratio*height/width;float limit=Math.min(maxW,maxH*r);float wanted=Math.max(w,h*r);w=clamp(wanted,Math.min(limit,Math.max(minW,minH*r)),limit);h=w/r;}if(l)left=ax-w;else right=ax+w;if(t)top=ay-h;else bottom=ay+h;}
    int[] pixels(){int x=Math.min(width-1,Math.max(0,Math.round(left*width))),y=Math.min(height-1,Math.max(0,Math.round(top*height)));int r=Math.max(x+1,Math.min(width,Math.round(right*width))),b=Math.max(y+1,Math.min(height,Math.round(bottom*height)));return new int[]{x,y,r-x,b-y};}
    private static float clamp(float n,float min,float max){return Math.max(min,Math.min(max,n));}
}
